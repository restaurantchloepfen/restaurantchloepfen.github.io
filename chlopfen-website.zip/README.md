# Chlöpfen Restaurant Website

A multi-page student restaurant concept website hosted with GitHub Pages.

## Pages
- `index.html` — Home
- `restaurant.html` — Restaurant and restaurant PDF
- `events.html` — Events and events PDF
- `careers.html` — Careers and careers PDF
- `contact.html` — Contact details
- `reservation.html` — Email-based reservation request form (not a live booking system)

## Customize
1. Replace placeholder text in the HTML pages.
2. Add `restaurant.pdf`, `events.pdf`, and `careers.pdf` to `pdfs/`.
3. Update `YOUR-EMAIL@example.com` in `script.js` to receive email requests.
4. Update address and opening hours in `contact.html` and the footer (footer markup appears in each HTML file).
5. Edit colors in `style.css` under `:root`.

## Publish
In your public GitHub repository, open **Settings → Pages**, choose **Deploy from a branch**, `main`, `/ (root)`, then save.

The site uses EB Garamond via Google Fonts for headings and Baskerville with system fallbacks for body text. Baskerville availability varies by device.
