// Mobile navigation: show or hide the menu on small screens.
const menuButton = document.querySelector('.menu-button');
const navigation = document.querySelector('.nav');
if (menuButton && navigation) {
  menuButton.addEventListener('click', () => {
    const isOpen = navigation.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(isOpen));
  });
}

// GitHub Pages cannot receive reservations on its own.
// This form opens the visitor's email application with a prepared request.
const reservationForm = document.querySelector('#reservation-form');
if (reservationForm) {
  reservationForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const recipient = 'YOUR-EMAIL@example.com'; // CHANGE THIS before publishing.
    if (recipient === 'YOUR-EMAIL@example.com') {
      alert('The restaurant must add its contact email in script.js before reservations can be requested.');
      return;
    }
    const data = new FormData(reservationForm);
    const subject = 'Reservation request — Chlöpfen';
    const message = [
      'Hello Chlöpfen,', '', 'I would like to request a reservation:',
      'Name: ' + data.get('name'),
      'Email: ' + data.get('email'),
      'Date: ' + data.get('date'),
      'Time: ' + data.get('time'),
      'Guests: ' + data.get('guests'),
      'Message: ' + (data.get('message') || 'None'), '',
      'Please confirm availability by email.'
    ].join('\n');
    window.location.href = 'mailto:' + recipient + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(message);
  });
}
